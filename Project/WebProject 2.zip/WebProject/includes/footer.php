</main>
<footer class="footer">FoodExpress &copy; 2026 — Online Food Ordering and Delivery Management System</footer>
<script src="<?= BASE_URL ?>/js/main.js"></script>
</body>
</html>