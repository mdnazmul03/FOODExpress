<?php
// Central place to set the project's base URL path.
// This is the URL folder your project sits in under htdocs.
// Example: if you browse the site at http://localhost/WebProject/...
// then BASE_URL should be "/WebProject".
// If you ever move the project so it IS the htdocs root
// (e.g. http://localhost/index.php works directly), set this to "".
if (!defined('BASE_URL')) {
    define('BASE_URL', '/WebProject');
}
?>
